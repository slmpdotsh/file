re2c: error: cannot combine TDFA(0) and staDFA
