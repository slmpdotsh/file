eof/eof_05.re:4:6: error: EOF rule without other rules doesn't make sense
