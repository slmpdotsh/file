eof/eof_07.re:4:6: error: $ rule found, but 're2c:eof' configuration is not set
