flex_syntax/namedef_error.re:7:0: error: curly braces for names only allowed with -F switch
