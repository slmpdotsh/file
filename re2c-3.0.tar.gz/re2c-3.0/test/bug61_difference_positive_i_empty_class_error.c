bug61_difference_positive_i_empty_class_error.re:3:4: error: empty character class
