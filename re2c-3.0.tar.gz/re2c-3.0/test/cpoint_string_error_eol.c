cpoint_string_error_eol.re:3:5: error: newline in character string
