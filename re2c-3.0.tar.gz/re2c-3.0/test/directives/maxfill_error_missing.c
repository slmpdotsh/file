re2c: error: cannot find block 'x' listed in `max:re2c` directive
