re2c: error: none of the blocks in `getstate:re2c` generate any code
