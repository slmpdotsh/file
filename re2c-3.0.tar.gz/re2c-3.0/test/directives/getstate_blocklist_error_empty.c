re2c: error: block 'empty' does not generate code, so it should not be listed in `getstate:re2c` directive
