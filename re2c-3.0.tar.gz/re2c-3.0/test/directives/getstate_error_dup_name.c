directives/getstate_error_dup_name.re:3:22: error: duplicate block 'x' on the list
