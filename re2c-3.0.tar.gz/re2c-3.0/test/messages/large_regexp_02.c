re2c: error: NFA has too many states
