re2c: error: bad argument 'xxx' to option --location-format (expected <gnu | msvc>)
