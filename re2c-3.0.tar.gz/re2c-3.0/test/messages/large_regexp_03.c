re2c: error: DFA has too many states
