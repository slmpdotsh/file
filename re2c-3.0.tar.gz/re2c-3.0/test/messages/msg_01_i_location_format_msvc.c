messages/msg_01_i_location_format_msvc.re(3,12): error: conditions are only allowed with '-c', '--conditions' option
