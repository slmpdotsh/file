re2c: error: NFA depth exceeds limits
