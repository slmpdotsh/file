messages/msg_01.re:3:12: error: conditions are only allowed with '-c', '--conditions' option
