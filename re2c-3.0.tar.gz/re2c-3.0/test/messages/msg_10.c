re2c: error: bad argument '-' to option -o, --output (expected <filename>)
