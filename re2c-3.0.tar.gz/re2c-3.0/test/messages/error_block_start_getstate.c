messages/error_block_start_getstate.re:7:16: error: ill-formed start of a block: expected a space, a newline, a colon followed by a list of colon-separated block names, or the end of block `*/`
