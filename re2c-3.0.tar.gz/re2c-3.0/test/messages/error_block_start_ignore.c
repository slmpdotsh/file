messages/error_block_start_ignore.re:7:14: error: ill-formed start of `ignore:re2c` block: expected a space, a newline, or the end of block `*/`
