re2c: error: bad argument 'xxx' to option --api, --input (expected <default | custom>)
