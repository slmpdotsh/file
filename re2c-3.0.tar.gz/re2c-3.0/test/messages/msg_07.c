re2c: error: bad argument 'xxx' to option --empty-class (expected <match-empty | match-none | error>)
