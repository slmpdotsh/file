re2c: error: bad argument 'xxx' to option --dfa-minimization (expected <table | moore>)
