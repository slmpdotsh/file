messages/error_getstate_without_option.re:2:16: error: `getstate:re2c` without `-f --storable-state` option
