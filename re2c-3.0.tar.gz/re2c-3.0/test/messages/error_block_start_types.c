messages/error_block_start_types.re:7:13: error: ill-formed start of a block: expected a space, a newline, a colon followed by a list of colon-separated block names, or the end of block `*/`
