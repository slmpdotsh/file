re2c: error: bad argument 'xxx' to option --posix-closure (expected <gor1 | gtop>)
