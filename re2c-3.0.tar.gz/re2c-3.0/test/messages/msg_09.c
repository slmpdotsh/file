re2c: error: bad argument 'xxx' to option --encoding-policy (expected <ignore | substitute | fail>)
