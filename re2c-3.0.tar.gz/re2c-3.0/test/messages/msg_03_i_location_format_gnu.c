messages/msg_03_i_location_format_gnu.re:2:17: error: unexpected end of input
