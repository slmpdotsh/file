messages/error_header_directive.re:8:14: error: ill-formed header directive: expected `/*!header:re2c:<on|off>` followed by a space, a newline or the end of block `*/`
