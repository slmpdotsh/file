encodings/unicode_group_C_u_encoding_policy_fail.re:12:4454: error: bad code point range: '0xD7FC - 0xF8FF'
