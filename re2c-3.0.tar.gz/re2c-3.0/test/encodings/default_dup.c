encodings/default_dup.re:4:3: error: code to default rule is already defined at line 3
