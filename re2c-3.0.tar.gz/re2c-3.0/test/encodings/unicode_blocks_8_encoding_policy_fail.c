encodings/unicode_blocks_8_encoding_policy_fail.re:323:21: error: bad code point range: '0xD800 - 0xDB7F'
