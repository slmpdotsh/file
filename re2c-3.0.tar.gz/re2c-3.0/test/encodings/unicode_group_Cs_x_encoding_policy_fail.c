encodings/unicode_group_Cs_x_encoding_policy_fail.re:12:8: error: bad code point range: '0xD800 - 0xDFFF'
