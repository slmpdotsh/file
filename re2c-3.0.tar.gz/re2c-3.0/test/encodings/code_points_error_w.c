encodings/code_points_error_w.re:3:11: error: bad code point: '0x10FFFF'
