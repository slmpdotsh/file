american_fuzzy_lop/001.re:2:10: error: unexpected end of input
