<?php
return array(
	'epubReader.meta.title'		=> "Epub Reader",
	'epubReader.meta.desc'		=> "Epub Reader is a small reading software, which supports epub format e-books; can support the directory preview, chapter switching and other powerful features!"
);