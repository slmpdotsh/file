<?php

return array(
	'epubReader.meta.title'		=> "Epub 阅读器",
	'epubReader.meta.desc'		=> "Epub 阅读器是一款绿色小巧的电子阅读软件，它支持epub格式的电子书;能支持目录预览，章节切换等强大功能!"
);